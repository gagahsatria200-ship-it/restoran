/**
 * Tambahkan menu fine dining Eropa ke database TANPA menghapus data yang sudah ada.
 * Menu dengan nama yang sama akan dilewati, jadi aman dijalankan berkali-kali.
 *
 * Jalankan dari folder api:  npm run seed:eropa
 */
const db = require("./config/database");
const initDatabase = require("./config/initDb");
const menuEropa = require("./data/menuEropa");

async function seedEropa() {
    await initDatabase();

    let ditambah = 0;
    let dilewati = 0;

    // Dimasukkan dari belakang (minuman → pembuka) agar urutan "Terbaru" di web
    // tampil seperti buku menu: pembuka, sup, hidangan utama, penutup, minuman.
    for (const item of [...menuEropa].reverse()) {
        const [existing] = await db.query("SELECT id FROM menu WHERE nama = ? LIMIT 1", [item.nama]);
        if (existing.length > 0) {
            dilewati++;
            continue;
        }
        await db.query(
            `INSERT INTO menu (nama, kategori, harga, deskripsi, status, gambar)
             VALUES (?, ?, ?, ?, ?, ?)`,
            [item.nama, item.kategori, item.harga, item.deskripsi, item.status, item.gambar]
        );
        ditambah++;
    }

    const [[{ total }]] = await db.query("SELECT COUNT(*) AS total FROM menu");
    console.log(`✅ Menu Eropa: ${ditambah} ditambahkan, ${dilewati} sudah ada (dilewati).`);
    console.log(`   Total menu di database sekarang: ${total}`);
}

if (require.main === module) {
    seedEropa()
        .then(() => process.exit(0))
        .catch((err) => {
            console.error("❌ Gagal menambahkan menu Eropa:", err.message);
            process.exit(1);
        });
}

module.exports = seedEropa;
