/**
 * MENU FINE DINING EROPA — "La Carte Européenne"
 * 48 hidangan Prancis, Italia, Spanyol & Austria.
 * Dipakai oleh seed.js (seed penuh) dan seed_eropa.js (tambah tanpa menghapus data lama).
 *
 * Catatan: semua resep disesuaikan tanpa babi & tanpa alkohol.
 */

const img = (id) => `https://images.unsplash.com/photo-${id}?auto=format&fit=crop&w=800&q=80`;

const menuEropa = [
    // --- HORS D'OEUVRE (Hidangan Pembuka) ---
    {
        nama: "Escargots de Bourgogne",
        kategori: "Hors d'Oeuvre",
        harga: 125000,
        deskripsi: "Enam siput Burgundy dipanggang dalam cangkangnya dengan mentega bawang putih, peterseli segar, dan perasan lemon. Disajikan bersama baguette hangat.",
        status: "tersedia",
        gambar: img("1585684278140-f6b0e42a9bc0")
    },
    {
        nama: "Foie Gras Torchon & Brioche",
        kategori: "Hors d'Oeuvre",
        harga: 245000,
        deskripsi: "Foie gras bebek yang dimasak perlahan hingga selembut mentega, disajikan dengan brioche panggang, selai buah ara, dan reduksi balsamic.",
        status: "tersedia",
        gambar: img("1758972574371-57cf8c42bae8")
    },
    {
        nama: "Carpaccio de Bœuf",
        kategori: "Hors d'Oeuvre",
        harga: 145000,
        deskripsi: "Irisan tipis tenderloin wagyu dengan minyak zaitun extra virgin, arugula, serutan Parmigiano, kaper, dan lada hitam tumbuk.",
        status: "tersedia",
        gambar: img("1769638913675-49d0fc2ca54c")
    },
    {
        nama: "Burrata, Tomat Pusaka & Basil",
        kategori: "Hors d'Oeuvre",
        harga: 135000,
        deskripsi: "Burrata Apulia yang creamy di atas tomat pusaka warna-warni, pesto basil, minyak zaitun, dan garam laut Maldon.",
        status: "tersedia",
        gambar: img("1649400454485-b8ad827f929d")
    },
    {
        nama: "Tartare de Bœuf",
        kategori: "Hors d'Oeuvre",
        harga: 155000,
        deskripsi: "Daging sapi cincang tangan dengan shallot, kaper, mustard Dijon, dan kuning telur confit. Disajikan dengan roti panggang tipis.",
        status: "tersedia",
        gambar: img("1571513062809-2ac71eab2656")
    },
    {
        nama: "Gambas al Ajillo",
        kategori: "Hors d'Oeuvre",
        harga: 135000,
        deskripsi: "Udang tumis minyak zaitun dan bawang putih dengan cabai guindilla serta paprika asap khas Spanyol, disajikan mendesis dalam cazuela.",
        status: "tersedia",
        gambar: img("1625943553852-781c6dd46faa")
    },
    {
        nama: "Bruschetta al Pomodoro",
        kategori: "Hors d'Oeuvre",
        harga: 85000,
        deskripsi: "Ciabatta panggang arang dengan tomat segar, bawang putih, daun basil, dan minyak zaitun Toscana.",
        status: "tersedia",
        gambar: img("1594978583693-8dfdfc93f052")
    },
    {
        nama: "Huîtres Fines de Claire",
        kategori: "Hors d'Oeuvre",
        harga: 295000,
        deskripsi: "Enam tiram segar di atas es serut dengan saus mignonette shallot, irisan lemon, dan roti gandum hitam bermentega.",
        status: "tersedia",
        gambar: img("1729269524124-1645db0b0ff5")
    },

    // --- SOUPE & SALADE ---
    {
        nama: "Soupe à l'Oignon Gratinée",
        kategori: "Soupe & Salade",
        harga: 95000,
        deskripsi: "Sup bawang bombay karamel dengan kaldu sapi pekat, ditutup crouton dan keju Gruyère yang dipanggang hingga keemasan.",
        status: "tersedia",
        gambar: img("1549203438-a7696aed4dac")
    },
    {
        nama: "Bouillabaisse Marseillaise",
        kategori: "Soupe & Salade",
        harga: 225000,
        deskripsi: "Sup ikan khas Marseille berisi kakap, udang, dan kerang dalam kaldu saffron, disajikan dengan rouille dan crouton bawang putih.",
        status: "tersedia",
        gambar: img("1621174438159-6a9a82405498")
    },
    {
        nama: "Bisque de Homard",
        kategori: "Soupe & Salade",
        harga: 165000,
        deskripsi: "Sup lobster kental dan lembut dari kaldu cangkang panggang, krim segar, dan sentuhan tarragon.",
        status: "tersedia",
        gambar: img("1741315034217-33e3438b205f")
    },
    {
        nama: "Velouté de Champignons à la Truffe",
        kategori: "Soupe & Salade",
        harga: 105000,
        deskripsi: "Sup krim jamur liar yang halus dengan tetesan minyak truffle hitam dan crouton mentega.",
        status: "tersedia",
        gambar: img("1619860859762-0569749bc607")
    },
    {
        nama: "Gazpacho Andaluz",
        kategori: "Soupe & Salade",
        harga: 85000,
        deskripsi: "Sup dingin khas Andalusia dari tomat matang, mentimun, paprika merah, dan minyak zaitun. Segar dan ringan.",
        status: "tersedia",
        gambar: img("1626200949817-4719bd60000b")
    },
    {
        nama: "Salade Niçoise",
        kategori: "Soupe & Salade",
        harga: 115000,
        deskripsi: "Tuna seared, telur setengah matang, buncis, kentang baby, zaitun Niçoise, dan tomat dengan vinaigrette Dijon.",
        status: "tersedia",
        gambar: img("1578687388049-079580e6eb2d")
    },
    {
        nama: "Caesar Salad Classique",
        kategori: "Soupe & Salade",
        harga: 95000,
        deskripsi: "Daun romaine renyah, dressing Caesar buatan sendiri, crouton sourdough, dan serutan Parmigiano-Reggiano.",
        status: "tersedia",
        gambar: img("1574926054530-540288c8e678")
    },

    // --- PLAT PRINCIPAL (Hidangan Utama) ---
    {
        nama: "Beef Wellington",
        kategori: "Plat Principal",
        harga: 485000,
        deskripsi: "Tenderloin sapi premium dibalut duxelles jamur dan crêpe, dipanggang dalam puff pastry berlapis mentega. Disajikan dengan pommes purée dan saus jus daging.",
        status: "tersedia",
        gambar: img("1675718341348-65224936b742")
    },
    {
        nama: "Bœuf Bourguignon",
        kategori: "Plat Principal",
        harga: 265000,
        deskripsi: "Daging sapi yang dimasak perlahan selama 6 jam bersama jamur, bawang mutiara, dan wortel dalam saus jus anggur merah non-alkohol.",
        status: "tersedia",
        gambar: img("1608500218987-0f2b3be34b47")
    },
    {
        nama: "Confit de Canard",
        kategori: "Plat Principal",
        harga: 285000,
        deskripsi: "Paha bebek confit yang renyah di luar dan lembut di dalam, dengan kentang sarladaise dan saus jeruk.",
        status: "tersedia",
        gambar: img("1675718343369-b2e46a5ceeca")
    },
    {
        nama: "Magret de Canard à l'Orange",
        kategori: "Plat Principal",
        harga: 315000,
        deskripsi: "Dada bebek panggang medium-rare dengan saus jeruk karamel, purée ubi, dan sayuran musiman.",
        status: "tersedia",
        gambar: img("1580554530778-ca36943938b2")
    },
    {
        nama: "Carré d'Agneau en Croûte d'Herbes",
        kategori: "Plat Principal",
        harga: 395000,
        deskripsi: "Rack domba Selandia Baru berbalut kerak herba Provence dan mustard, disajikan dengan ratatouille dan jus rosemary.",
        status: "tersedia",
        gambar: img("1692106914421-e04e1066bd62")
    },
    {
        nama: "Filet Mignon, Sauce Béarnaise",
        kategori: "Plat Principal",
        harga: 425000,
        deskripsi: "Tenderloin sapi 200 gram dipanggang sesuai selera dengan mentega herba, saus béarnaise, dan pommes frites.",
        status: "tersedia",
        gambar: img("1726677730666-fdc08a8da464")
    },
    {
        nama: "Poulet Rôti à l'Estragon",
        kategori: "Plat Principal",
        harga: 225000,
        deskripsi: "Ayam kampung utuh dipanggang dengan mentega tarragon, bawang putih, dan lemon. Disajikan dengan sayuran akar panggang.",
        status: "tersedia",
        gambar: img("1598103442097-8b74394b95c6")
    },
    {
        nama: "Ossobuco alla Milanese",
        kategori: "Plat Principal",
        harga: 345000,
        deskripsi: "Shank sapi muda yang di-braise lembut dalam saus tomat dan sayuran, disajikan dengan risotto saffron dan gremolata.",
        status: "tersedia",
        gambar: img("1605209660425-28a0afbbed8b")
    },
    {
        nama: "Risotto ai Funghi Porcini",
        kategori: "Plat Principal",
        harga: 195000,
        deskripsi: "Risotto Carnaroli creamy dengan jamur porcini, mentega, dan Parmigiano-Reggiano yang diperam 24 bulan.",
        status: "tersedia",
        gambar: img("1609770424775-39ec362f2d94")
    },
    {
        nama: "Tagliatelle al Tartufo Nero",
        kategori: "Plat Principal",
        harga: 285000,
        deskripsi: "Tagliatelle buatan tangan dengan saus mentega Parmigiano dan serutan truffle hitam segar langsung di meja Anda.",
        status: "tersedia",
        gambar: img("1643644598156-858b6d62405b")
    },
    {
        nama: "Paella Valenciana de Mariscos",
        kategori: "Plat Principal",
        harga: 345000,
        deskripsi: "Nasi bomba saffron dimasak dalam paellera dengan udang, kerang, cumi, dan ayam. Porsi untuk dua orang.",
        status: "tersedia",
        gambar: img("1623961990059-28356e226a77")
    },
    {
        nama: "Loup de Mer Grillé",
        kategori: "Plat Principal",
        harga: 295000,
        deskripsi: "Ikan kakap putih (sea bass) utuh dipanggang arang dengan minyak zaitun, herba Provence, dan jeruk nipis.",
        status: "tersedia",
        gambar: img("1700760933440-5c6a4b4224a4")
    },
    {
        nama: "Moules Marinières",
        kategori: "Plat Principal",
        harga: 195000,
        deskripsi: "Satu panci kerang biru yang dikukus dengan bawang putih, shallot, peterseli, dan krim. Disajikan dengan pommes frites.",
        status: "tersedia",
        gambar: img("1600265721436-734abbfe2137")
    },
    {
        nama: "Wiener Schnitzel",
        kategori: "Plat Principal",
        harga: 245000,
        deskripsi: "Daging sapi muda tipis berbalut tepung roti, digoreng dengan mentega hingga keemasan. Disajikan dengan salad kentang Wina dan lemon.",
        status: "tersedia",
        gambar: img("1599921841143-819065a55cc6")
    },
    {
        nama: "Ratatouille Provençale",
        kategori: "Plat Principal",
        harga: 145000,
        deskripsi: "Terong, zukini, paprika, dan tomat khas musim panas Provence yang dipanggang berlapis dengan herba segar. Vegetarian.",
        status: "tersedia",
        gambar: img("1652622550740-f90d03edfbf0")
    },
    {
        nama: "Saumon Rôti, Sauce Vierge",
        kategori: "Plat Principal",
        harga: 285000,
        deskripsi: "Fillet salmon Norwegia berkulit renyah dengan saus vierge tomat-basil dan sayuran hijau musiman.",
        status: "tersedia",
        gambar: img("1712334562767-5d366d0c40d9")
    },

    // --- PÂTISSERIE (Hidangan Penutup) ---
    {
        nama: "Crème Brûlée à la Vanille",
        kategori: "Pâtisserie",
        harga: 75000,
        deskripsi: "Custard vanila Madagaskar yang lembut dengan lapisan karamel renyah yang dibakar sesaat sebelum disajikan.",
        status: "tersedia",
        gambar: img("1615235739538-95040f341ba8")
    },
    {
        nama: "Tarte Tatin",
        kategori: "Pâtisserie",
        harga: 85000,
        deskripsi: "Tart apel karamel terbalik khas Prancis, disajikan hangat dengan crème fraîche.",
        status: "tersedia",
        gambar: img("1624299831638-82c15fcafd2b")
    },
    {
        nama: "Mille-Feuille Vanille",
        kategori: "Pâtisserie",
        harga: 85000,
        deskripsi: "Tiga lapis puff pastry karamel dengan crème pâtissière vanila yang lembut dan stroberi segar.",
        status: "tersedia",
        gambar: img("1587122569949-ae6e755c6bdc")
    },
    {
        nama: "Profiteroles au Chocolat",
        kategori: "Pâtisserie",
        harga: 80000,
        deskripsi: "Choux pastry isi es krim vanila, disiram saus cokelat hitam hangat.",
        status: "tersedia",
        gambar: img("1606163050616-538bc0360157")
    },
    {
        nama: "Fondant au Chocolat",
        kategori: "Pâtisserie",
        harga: 85000,
        deskripsi: "Kue cokelat hitam 70% dengan bagian tengah yang lumer, disajikan dengan es krim vanila.",
        status: "tersedia",
        gambar: img("1505252929202-c4f39cda4d49")
    },
    {
        nama: "Macarons Parisiens",
        kategori: "Pâtisserie",
        harga: 95000,
        deskripsi: "Enam macaron renyah-lembut aneka rasa: pistachio, raspberry, vanila, cokelat, salted caramel, dan lemon.",
        status: "tersedia",
        gambar: img("1569864358642-9d1684040f43")
    },
    {
        nama: "Apfelstrudel Wina",
        kategori: "Pâtisserie",
        harga: 80000,
        deskripsi: "Pastry tipis berlapis isi apel, kismis, dan kayu manis, disajikan hangat dengan saus vanila.",
        status: "tersedia",
        gambar: img("1702742400971-10b0c41a11a7")
    },
    {
        nama: "Sachertorte",
        kategori: "Pâtisserie",
        harga: 85000,
        deskripsi: "Kue cokelat klasik Wina dengan selai aprikot dan glasir cokelat pekat, disajikan dengan krim kocok.",
        status: "tersedia",
        gambar: img("1627394728092-d080498ae85d")
    },
    {
        nama: "Cannoli Siciliani",
        kategori: "Pâtisserie",
        harga: 75000,
        deskripsi: "Kulit pastry renyah isi krim ricotta manis, kulit jeruk candied, dan pistachio cincang.",
        status: "tersedia",
        gambar: img("1611292984550-6dd8def2e668")
    },
    {
        nama: "Crêpes au Citron & Sucre",
        kategori: "Pâtisserie",
        harga: 70000,
        deskripsi: "Crêpe tipis ala Bretagne dengan mentega, gula, dan perasan lemon segar.",
        status: "tersedia",
        gambar: img("1656057205408-4a0a62cf2dfb")
    },

    // --- BOISSONS (Minuman) ---
    {
        nama: "Espresso Ristretto",
        kategori: "Boissons",
        harga: 45000,
        deskripsi: "Ekstraksi pendek biji arabika pilihan, pekat dan beraroma dengan crema keemasan.",
        status: "tersedia",
        gambar: img("1579992357154-faf4bde95b3d")
    },
    {
        nama: "Cappuccino Italiano",
        kategori: "Boissons",
        harga: 55000,
        deskripsi: "Double espresso dengan foam susu yang lembut ala kafe di Milan.",
        status: "tersedia",
        gambar: img("1506372023823-741c83b836fe")
    },
    {
        nama: "Affogato al Caffè",
        kategori: "Boissons",
        harga: 65000,
        deskripsi: "Satu scoop gelato vanila yang disiram espresso panas tepat sebelum disajikan.",
        status: "tersedia",
        gambar: img("1436491911682-72ab1d398f59")
    },
    {
        nama: "Chocolat Chaud Parisien",
        kategori: "Boissons",
        harga: 65000,
        deskripsi: "Cokelat panas kental ala Paris dari cokelat hitam leleh dan susu murni, dengan krim kocok.",
        status: "tersedia",
        gambar: img("1517578239113-b03992dcdd25")
    },
    {
        nama: "Citron Pressé",
        kategori: "Boissons",
        harga: 45000,
        deskripsi: "Lemon peras segar disajikan terpisah dengan air dingin dan sirup gula untuk diracik sesuai selera.",
        status: "tersedia",
        gambar: img("1623084921164-4a8c5c37a912")
    },
    {
        nama: "Rosé Pétillant Sans Alcool",
        kategori: "Boissons",
        harga: 75000,
        deskripsi: "Mocktail berkilau dari jus anggur merah, raspberry, dan soda, disajikan dalam gelas coupe.",
        status: "tersedia",
        gambar: img("1527761939622-9119094630cf")
    },
    {
        nama: "Thé Earl Grey & Madeleine",
        kategori: "Boissons",
        harga: 55000,
        deskripsi: "Teh hitam Earl Grey beraroma bergamot, disajikan dengan dua madeleine mentega hangat.",
        status: "tersedia",
        gambar: img("1562097691-905c0a23ee19")
    }
];

module.exports = menuEropa;
