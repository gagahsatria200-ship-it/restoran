/**
 * RASA NUSANTARA — Maison de Cuisine
 * Frontend Vanilla JS: katalog menu untuk tamu + Mode Admin (CRUD).
 */

// Deteksi URL API: relative path jika disajikan oleh server Express (port 3000), selain itu fallback ke localhost:3000
const API_BASE = (window.location.origin && window.location.origin.includes(':3000'))
    ? '/api'
    : 'http://localhost:3000/api';

const DEFAULT_FOOD_IMAGE = 'https://images.unsplash.com/photo-1546069901-ba9599a7e63c?auto=format&fit=crop&w=800&q=80';

// Urutan kategori mengikuti alur hidangan (pembuka → utama → penutup → minuman).
// Baris pertama: La Carte Européenne, baris kedua: Nusantara & Internasional.
const EURO_CATEGORIES = ["Hors d'Oeuvre", 'Soupe & Salade', 'Plat Principal', 'Pâtisserie', 'Boissons'];
const COURSE_ORDER = [
    ...EURO_CATEGORIES,
    'Makanan Utama',
    'Seafood',
    'Steak & Western',
    'Mie & Pasta',
    'Cemilan',
    'Dessert',
    'Minuman'
];

const SIGNATURE_CATEGORY = 'Plat Principal';

// ========================================================
// STATE
// ========================================================
const state = {
    search: '',
    category: 'Semua',
    status: 'semua',
    sortBy: 'id',
    order: 'DESC',
    page: 1,
    limit: 12,
    totalPages: 1,
    totalItems: 0,
    items: [],
    signatureItems: [],
    categories: [],
    stats: null,
    deleteTargetId: null,
    currentDetailItem: null,
    view: storageGet('rn_view') === 'list' ? 'list' : 'grid',
    admin: storageGet('rn_admin') === '1'
};

let menuRequestId = 0;

// ========================================================
// DOM
// ========================================================
const $ = (id) => document.getElementById(id);

const elements = {
    siteHeader: $('siteHeader'),
    btnBurger: $('btnBurger'),
    mobileNav: $('mobileNav'),
    btnAdminToggle: $('btnAdminToggle'),
    serverStatus: $('serverStatus'),

    searchInput: $('searchInput'),
    btnClearSearch: $('btnClearSearch'),
    sortSelect: $('sortSelect'),
    statusFilter: $('statusFilter'),
    btnResetFilters: $('btnResetFilters'),
    categoriesContainer: $('categoriesContainer'),
    resultInfoText: $('resultInfoText'),
    limitSelect: $('limitSelect'),
    menuGrid: $('menuGrid'),
    emptyState: $('emptyState'),
    btnEmptyReset: $('btnEmptyReset'),
    paginationContainer: $('paginationContainer'),
    btnPrevPage: $('btnPrevPage'),
    btnNextPage: $('btnNextPage'),
    pageNumbers: $('pageNumbers'),
    viewButtons: document.querySelectorAll('.view-btn'),
    signatureGrid: $('signatureGrid'),

    // Statistik
    statTotalMenu: $('statTotalMenu'),
    statTotalKategori: $('statTotalKategori'),
    statHargaMin: $('statHargaMin'),
    statTersedia: $('statTersedia'),

    // Modal form
    btnOpenAddModal: $('btnOpenAddModal'),
    menuModal: $('menuModal'),
    modalTitle: $('modalTitle'),
    btnCloseModal: $('btnCloseModal'),
    btnCancelModal: $('btnCancelModal'),
    menuForm: $('menuForm'),
    menuId: $('menuId'),
    inputNama: $('inputNama'),
    inputKategori: $('inputKategori'),
    inputHarga: $('inputHarga'),
    inputStatus: $('inputStatus'),
    inputDeskripsi: $('inputDeskripsi'),
    inputGambar: $('inputGambar'),
    imagePreview: $('imagePreview'),
    btnSubmitMenu: $('btnSubmitMenu'),

    // Modal detail
    detailModal: $('detailModal'),
    btnCloseDetail: $('btnCloseDetail'),
    detailHeroImage: $('detailHeroImage'),
    detailCategory: $('detailCategory'),
    detailNama: $('detailNama'),
    detailHarga: $('detailHarga'),
    detailStatus: $('detailStatus'),
    detailDeskripsi: $('detailDeskripsi'),
    detailId: $('detailId'),
    detailCreatedAt: $('detailCreatedAt'),
    btnEditFromDetail: $('btnEditFromDetail'),
    btnDeleteFromDetail: $('btnDeleteFromDetail'),

    // Modal hapus
    deleteModal: $('deleteModal'),
    deleteTargetName: $('deleteTargetName'),
    btnCancelDelete: $('btnCancelDelete'),
    btnConfirmDelete: $('btnConfirmDelete'),

    toastContainer: $('toastContainer')
};

// ========================================================
// UTILITAS
// ========================================================
function storageGet(key) {
    try { return window.localStorage.getItem(key); } catch { return null; }
}

function storageSet(key, value) {
    try { window.localStorage.setItem(key, value); } catch { /* abaikan */ }
}

function formatRupiah(number) {
    const num = Math.round(Number(number) || 0);
    return new Intl.NumberFormat('id-ID', {
        style: 'currency',
        currency: 'IDR',
        maximumFractionDigits: 0
    }).format(num);
}

function formatDate(dateString) {
    if (!dateString) return '—';
    const d = new Date(dateString);
    if (isNaN(d.getTime())) return dateString;
    return d.toLocaleDateString('id-ID', { day: 'numeric', month: 'short', year: 'numeric' });
}

function escapeHtml(str) {
    if (str === null || str === undefined) return '';
    return String(str)
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#039;');
}

// Dipanggil oleh atribut onerror pada <img>: ganti foto rusak dengan monogram elegan
function handleImgError(img) {
    const box = img.parentElement;
    if (box) box.classList.add('no-img');
    img.remove();
}

function showToast(message, type = 'success') {
    const toast = document.createElement('div');
    toast.className = `toast ${type}`;
    const icons = { success: '✓', error: '!', info: '·' };
    toast.innerHTML = `
        <span class="toast-icon">${icons[type] || '·'}</span>
        <span class="toast-message">${escapeHtml(message)}</span>
    `;
    elements.toastContainer.appendChild(toast);

    setTimeout(() => {
        toast.style.opacity = '0';
        toast.style.transform = 'translateY(10px)';
        setTimeout(() => toast.remove(), 300);
    }, 3200);
}

function sortCategories(list) {
    const rank = (name) => {
        const i = COURSE_ORDER.indexOf(name);
        return i === -1 ? COURSE_ORDER.length : i;
    };
    return [...list].sort((a, b) => rank(a.kategori) - rank(b.kategori) || a.kategori.localeCompare(b.kategori));
}

function scrollToMenu() {
    // Gulir ke tab kategori (bukan judul section) agar hasil langsung terlihat
    const target = elements.categoriesContainer;
    if (!target) return;
    const headerH = elements.siteHeader.offsetHeight || 70;
    const top = target.getBoundingClientRect().top + window.scrollY - headerH - 24;
    window.scrollTo({ top, behavior: 'smooth' });
}

// ========================================================
// API
// ========================================================
async function checkServerHealth() {
    const textEl = elements.serverStatus.querySelector('.status-text');
    try {
        const res = await fetch(`${API_BASE}/health`);
        if (!res.ok) throw new Error();
        elements.serverStatus.className = 'server-status online';
        textEl.textContent = 'API Terhubung';
    } catch {
        elements.serverStatus.className = 'server-status offline';
        textEl.textContent = 'API Terputus';
    }
}

async function loadStats() {
    try {
        const res = await fetch(`${API_BASE}/menu/stats`);
        const json = await res.json();
        if (json.success && json.data) {
            state.stats = json.data;
            elements.statTotalMenu.textContent = json.data.totalMenu || 0;
            elements.statTotalKategori.textContent = json.data.totalKategori || 0;
            elements.statHargaMin.textContent = formatRupiah(json.data.hargaTerendah);
            elements.statTersedia.textContent = json.data.totalTersedia || 0;
            const badgeAll = $('badgeAll');
            if (badgeAll) badgeAll.textContent = json.data.totalMenu;
        }
    } catch (err) {
        console.warn('Gagal memuat statistik:', err);
    }
}

async function loadCategories() {
    try {
        const res = await fetch(`${API_BASE}/menu/categories`);
        const json = await res.json();
        if (json.success && Array.isArray(json.data)) {
            state.categories = sortCategories(json.data);
            renderCategories();
            populateCategorySelect();
        }
    } catch (err) {
        console.warn('Gagal memuat kategori:', err);
    }
}

function renderCategories() {
    const total = state.stats ? state.stats.totalMenu : '…';
    const tab = (value, label, count) => {
        const isActive = state.category === value;
        return `
            <button class="cat-tab ${isActive ? 'active' : ''}" data-category="${escapeHtml(value)}" role="tab" aria-selected="${isActive}">
                ${escapeHtml(label)} <sup${value === 'Semua' ? ' id="badgeAll"' : ''}>${count}</sup>
            </button>
        `;
    };

    const euro = state.categories.filter(c => EURO_CATEGORIES.includes(c.kategori));
    const others = state.categories.filter(c => !EURO_CATEGORIES.includes(c.kategori));

    let html = tab('Semua', 'Semua', total);
    html += euro.map(c => tab(c.kategori, c.kategori, c.count)).join('');
    if (euro.length && others.length) html += '<span class="cat-break" aria-hidden="true"></span>';
    html += others.map(c => tab(c.kategori, c.kategori, c.count)).join('');

    elements.categoriesContainer.innerHTML = html;

    // Di layar kecil tab bisa digeser: pastikan tab aktif terlihat (hanya geser horizontal, halaman tidak ikut melompat)
    const box = elements.categoriesContainer;
    const active = box.querySelector('.cat-tab.active');
    if (active && box.scrollWidth > box.clientWidth) {
        box.scrollTo({ left: active.offsetLeft - (box.clientWidth - active.offsetWidth) / 2, behavior: 'smooth' });
    }
}

function populateCategorySelect() {
    const names = new Set(COURSE_ORDER);
    state.categories.forEach(c => names.add(c.kategori));
    const current = elements.inputKategori.value;

    elements.inputKategori.innerHTML = '<option value="">Pilih kategori</option>' +
        [...names].map(n => `<option value="${escapeHtml(n)}">${escapeHtml(n)}</option>`).join('');

    if (current) elements.inputKategori.value = current;
}

async function loadSignature() {
    try {
        const params = new URLSearchParams({ kategori: SIGNATURE_CATEGORY, sortBy: 'harga', order: 'DESC', limit: 3, page: 1 });
        let res = await fetch(`${API_BASE}/menu?${params}`);
        let json = await res.json();
        let items = json.data || [];

        // Fallback bila kategori Eropa belum di-seed: ambil 3 hidangan termahal dari semua kategori
        if (items.length < 3) {
            res = await fetch(`${API_BASE}/menu?sortBy=harga&order=DESC&limit=3&page=1`);
            json = await res.json();
            items = json.data || [];
        }

        state.signatureItems = items;
        renderSignature();
    } catch (err) {
        console.warn('Gagal memuat signature:', err);
        elements.signatureGrid.innerHTML = '';
    }
}

function renderSignature() {
    elements.signatureGrid.innerHTML = state.signatureItems.map((item, i) => `
        <article class="sig-card" data-id="${item.id}" tabindex="0" aria-label="Lihat detail ${escapeHtml(item.nama)}">
            <div class="sig-media">
                <img src="${escapeHtml(item.gambar || DEFAULT_FOOD_IMAGE)}" alt="${escapeHtml(item.nama)}" loading="lazy" onerror="handleImgError(this)">
            </div>
            <span class="sig-num">N° 0${i + 1}</span>
            <h3 class="sig-name">${escapeHtml(item.nama)}</h3>
            <p class="sig-desc">${escapeHtml(item.deskripsi || '')}</p>
            <span class="sig-price">${formatRupiah(item.harga)}</span>
        </article>
    `).join('');
}

async function loadMenu() {
    const requestId = ++menuRequestId;
    renderLoadingSkeletons();

    try {
        const params = new URLSearchParams();
        params.append('page', state.page);
        params.append('limit', state.limit);
        params.append('sortBy', state.sortBy);
        params.append('order', state.order);

        if (state.search.trim()) params.append('search', state.search.trim());
        if (state.category && state.category !== 'Semua') params.append('kategori', state.category);
        if (state.status && state.status !== 'semua') params.append('status', state.status);

        const res = await fetch(`${API_BASE}/menu?${params.toString()}`);
        if (!res.ok) throw new Error('Gagal mengambil data menu');
        const json = await res.json();

        // Abaikan respons lama jika sudah ada permintaan yang lebih baru
        if (requestId !== menuRequestId) return;

        state.items = json.data || [];
        state.totalItems = json.pagination.totalItems;
        state.totalPages = json.pagination.totalPages;
        state.page = json.pagination.currentPage;

        renderMenuGrid();
        renderPagination();
        updateResultInfo();
    } catch (err) {
        if (requestId !== menuRequestId) return;
        console.error('Error loadMenu:', err);
        elements.menuGrid.classList.remove('is-list');
        elements.menuGrid.innerHTML = `
            <div class="empty-state">
                <span class="ornament" aria-hidden="true"></span>
                <h3>Dapur sedang tidak terhubung</h3>
                <p>Menu belum bisa dimuat. Pastikan server backend di port 3000 sedang berjalan.</p>
                <button class="btn btn-outline" id="btnRetryMenu">Coba Lagi</button>
            </div>
        `;
        $('btnRetryMenu').addEventListener('click', loadMenu);
        elements.resultInfoText.textContent = 'Menu belum tersedia';
        elements.emptyState.classList.add('hidden');
        elements.paginationContainer.classList.add('hidden');
    }
}

function renderLoadingSkeletons() {
    const count = state.view === 'list' ? 6 : 3;
    elements.menuGrid.classList.toggle('is-list', state.view === 'list');
    elements.menuGrid.innerHTML = '<div class="skeleton-card"></div>'.repeat(count);
    elements.emptyState.classList.add('hidden');
}

function updateResultInfo() {
    if (state.totalItems === 0) {
        elements.resultInfoText.textContent = 'Tidak ada hidangan yang ditemukan';
        return;
    }
    const start = state.limit === 0 ? 1 : ((state.page - 1) * state.limit) + 1;
    const end = state.limit === 0 ? state.totalItems : Math.min(state.page * state.limit, state.totalItems);
    elements.resultInfoText.textContent = `Menampilkan ${start}–${end} dari ${state.totalItems} hidangan`;
}

const ICON_EDIT = '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M16.5 3.5a2.1 2.1 0 0 1 3 3L8 18l-4 1 1-4z"/></svg>';
const ICON_DELETE = '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><polyline points="4 7 20 7"/><path d="M18 7l-1 13H7L6 7"/><path d="M9 7V4h6v3"/></svg>';

function adminButtons(item) {
    return `
        <div class="card-admin">
            <button class="action-btn edit-btn" title="Edit hidangan" aria-label="Edit ${escapeHtml(item.nama)}">${ICON_EDIT}</button>
            <button class="action-btn delete-btn" title="Hapus hidangan" aria-label="Hapus ${escapeHtml(item.nama)}">${ICON_DELETE}</button>
        </div>
    `;
}

function renderGridCard(item, index) {
    const isTersedia = item.status === 'tersedia';
    const imgUrl = item.gambar || DEFAULT_FOOD_IMAGE;
    return `
        <article class="menu-card ${isTersedia ? '' : 'is-habis'}" data-id="${item.id}" tabindex="0" style="animation-delay:${Math.min(index, 8) * 60}ms">
            <div class="card-media">
                <img src="${escapeHtml(imgUrl)}" alt="${escapeHtml(item.nama)}" loading="lazy" onerror="handleImgError(this)">
                ${isTersedia ? '' : '<span class="sold-tag">Habis</span>'}
            </div>
            ${adminButtons(item)}
            <div class="card-body">
                <span class="card-cat">${escapeHtml(item.kategori)}</span>
                <h3 class="card-title">${escapeHtml(item.nama)}</h3>
                <p class="card-desc">${escapeHtml(item.deskripsi || 'Hidangan istimewa racikan chef kami.')}</p>
                <div class="card-foot">
                    <span class="card-price">${formatRupiah(item.harga)}</span>
                    <span class="card-rule"></span>
                    <span class="card-more">Détails</span>
                </div>
            </div>
        </article>
    `;
}

function renderListItem(item, index) {
    const isTersedia = item.status === 'tersedia';
    return `
        <article class="carte-item ${isTersedia ? '' : 'is-habis'}" data-id="${item.id}" tabindex="0" style="animation-delay:${Math.min(index, 10) * 40}ms">
            <div class="carte-line">
                <h3 class="carte-name">${escapeHtml(item.nama)}</h3>
                <span class="carte-dots"></span>
                <span class="carte-price">${formatRupiah(item.harga)}</span>
            </div>
            <p class="carte-desc">${escapeHtml(item.deskripsi || 'Hidangan istimewa racikan chef kami.')}</p>
            <div class="carte-meta">
                <span>${escapeHtml(item.kategori)}</span>
                ${isTersedia ? '' : '<span class="sold">· Habis</span>'}
                ${adminButtons(item)}
            </div>
        </article>
    `;
}

function renderMenuGrid() {
    elements.menuGrid.classList.toggle('is-list', state.view === 'list');

    if (state.items.length === 0) {
        elements.menuGrid.innerHTML = '';
        elements.emptyState.classList.remove('hidden');
        elements.paginationContainer.classList.add('hidden');
        return;
    }

    elements.emptyState.classList.add('hidden');
    const render = state.view === 'list' ? renderListItem : renderGridCard;
    elements.menuGrid.innerHTML = state.items.map(render).join('');
}

function findItem(id) {
    return state.items.find(i => String(i.id) === String(id))
        || state.signatureItems.find(i => String(i.id) === String(id));
}

// Satu listener untuk semua kartu (event delegation)
elements.menuGrid.addEventListener('click', (e) => {
    const card = e.target.closest('[data-id]');
    if (!card) return;
    const item = findItem(card.getAttribute('data-id'));

    if (e.target.closest('.edit-btn')) {
        e.stopPropagation();
        openEditModal(item);
    } else if (e.target.closest('.delete-btn')) {
        e.stopPropagation();
        openDeleteModal(item);
    } else {
        openDetailModal(item);
    }
});

elements.menuGrid.addEventListener('keydown', (e) => {
    if (e.key !== 'Enter' || e.target.closest('button')) return;
    const card = e.target.closest('[data-id]');
    if (card) openDetailModal(findItem(card.getAttribute('data-id')));
});

elements.signatureGrid.addEventListener('click', (e) => {
    const card = e.target.closest('[data-id]');
    if (card) openDetailModal(findItem(card.getAttribute('data-id')));
});

elements.signatureGrid.addEventListener('keydown', (e) => {
    if (e.key !== 'Enter') return;
    const card = e.target.closest('[data-id]');
    if (card) openDetailModal(findItem(card.getAttribute('data-id')));
});

// ========================================================
// PAGINATION
// ========================================================
function renderPagination() {
    if (state.totalPages <= 1) {
        elements.paginationContainer.classList.add('hidden');
        return;
    }

    elements.paginationContainer.classList.remove('hidden');
    elements.btnPrevPage.disabled = state.page <= 1;
    elements.btnNextPage.disabled = state.page >= state.totalPages;

    const total = state.totalPages;
    const current = state.page;
    const range = [1];
    for (let i = Math.max(2, current - 1); i <= Math.min(total - 1, current + 1); i++) range.push(i);
    if (total > 1) range.push(total);

    const pages = [...new Set(range)].sort((a, b) => a - b);
    let html = '';
    let last = 0;
    pages.forEach(p => {
        if (p - last > 1) html += '<span class="num-ellipsis">…</span>';
        html += `<button class="num-btn ${p === current ? 'active' : ''}" data-page="${p}" aria-label="Halaman ${p}" ${p === current ? 'aria-current="page"' : ''}>${p}</button>`;
        last = p;
    });
    elements.pageNumbers.innerHTML = html;
}

elements.pageNumbers.addEventListener('click', (e) => {
    const btn = e.target.closest('.num-btn');
    if (!btn) return;
    const pageNum = parseInt(btn.getAttribute('data-page'), 10);
    if (pageNum !== state.page) goToPage(pageNum);
});

function goToPage(page) {
    state.page = page;
    loadMenu();
    scrollToMenu();
}

elements.btnPrevPage.addEventListener('click', () => { if (state.page > 1) goToPage(state.page - 1); });
elements.btnNextPage.addEventListener('click', () => { if (state.page < state.totalPages) goToPage(state.page + 1); });

// ========================================================
// MODAL
// ========================================================
const allModals = [elements.menuModal, elements.detailModal, elements.deleteModal];

function syncBodyScroll() {
    const anyOpen = allModals.some(m => !m.classList.contains('hidden'));
    document.body.classList.toggle('modal-open', anyOpen);
}

function showModal(modal) {
    modal.classList.remove('hidden');
    syncBodyScroll();
}

function hideModal(modal) {
    modal.classList.add('hidden');
    syncBodyScroll();
}

function openAddModal() {
    elements.modalTitle.textContent = 'Tambah Menu Baru';
    elements.menuForm.reset();
    elements.menuId.value = '';
    elements.inputStatus.value = 'tersedia';
    if (state.category !== 'Semua') elements.inputKategori.value = state.category;
    elements.imagePreview.src = '';
    elements.imagePreview.classList.add('hidden');
    showModal(elements.menuModal);
    elements.inputNama.focus();
}

function openEditModal(item) {
    if (!item) return;
    elements.modalTitle.textContent = 'Edit Hidangan';
    elements.menuId.value = item.id;
    elements.inputNama.value = item.nama;

    // Pastikan kategori lama tetap ada di pilihan
    if (![...elements.inputKategori.options].some(o => o.value === item.kategori)) {
        elements.inputKategori.insertAdjacentHTML('beforeend', `<option value="${escapeHtml(item.kategori)}">${escapeHtml(item.kategori)}</option>`);
    }
    elements.inputKategori.value = item.kategori;
    elements.inputHarga.value = item.harga;
    elements.inputStatus.value = item.status || 'tersedia';
    elements.inputDeskripsi.value = item.deskripsi || '';
    elements.inputGambar.value = item.gambar || '';

    if (item.gambar) {
        elements.imagePreview.src = item.gambar;
        elements.imagePreview.classList.remove('hidden');
    } else {
        elements.imagePreview.src = '';
        elements.imagePreview.classList.add('hidden');
    }

    showModal(elements.menuModal);
    elements.inputNama.focus();
}

function closeMenuModal() {
    hideModal(elements.menuModal);
}

function openDetailModal(item) {
    if (!item) return;
    state.currentDetailItem = item;

    const imgUrl = item.gambar || DEFAULT_FOOD_IMAGE;
    elements.detailHeroImage.classList.remove('no-img');
    elements.detailHeroImage.innerHTML = `<img src="${escapeHtml(imgUrl)}" alt="${escapeHtml(item.nama)}" onerror="handleImgError(this)">`;

    elements.detailCategory.textContent = item.kategori;
    elements.detailNama.textContent = item.nama;
    elements.detailHarga.textContent = formatRupiah(item.harga);

    const isTersedia = item.status === 'tersedia';
    elements.detailStatus.textContent = isTersedia ? 'Tersedia' : 'Habis';
    elements.detailStatus.className = `status-badge ${isTersedia ? 'status-tersedia' : 'status-habis'}`;

    elements.detailDeskripsi.textContent = item.deskripsi || 'Hidangan istimewa racikan chef kami.';
    elements.detailId.textContent = `#${item.id}`;
    elements.detailCreatedAt.textContent = formatDate(item.created_at);

    showModal(elements.detailModal);
    elements.btnCloseDetail.focus({ preventScroll: true });
}

function closeDetailModal() {
    hideModal(elements.detailModal);
    state.currentDetailItem = null;
}

function openDeleteModal(item) {
    if (!item) return;
    state.deleteTargetId = item.id;
    elements.deleteTargetName.textContent = `“${item.nama}”`;
    showModal(elements.deleteModal);
}

function closeDeleteModal() {
    hideModal(elements.deleteModal);
    state.deleteTargetId = null;
}

// ========================================================
// CRUD
// ========================================================
async function refreshAll() {
    await Promise.all([loadStats(), loadCategories(), loadSignature()]);
    await loadMenu();
}

async function handleMenuSubmit(e) {
    e.preventDefault();

    const id = elements.menuId.value;
    const isEdit = Boolean(id);

    const payload = {
        nama: elements.inputNama.value.trim(),
        kategori: elements.inputKategori.value.trim(),
        harga: parseFloat(elements.inputHarga.value),
        status: elements.inputStatus.value,
        deskripsi: elements.inputDeskripsi.value.trim(),
        gambar: elements.inputGambar.value.trim() || null
    };

    if (!payload.nama || !payload.kategori || isNaN(payload.harga) || payload.harga <= 0) {
        showToast('Mohon lengkapi nama, kategori, dan harga yang valid.', 'error');
        return;
    }

    const btnText = elements.btnSubmitMenu.querySelector('.btn-text');
    elements.btnSubmitMenu.disabled = true;
    btnText.textContent = 'Menyimpan…';

    try {
        const url = isEdit ? `${API_BASE}/menu/${id}` : `${API_BASE}/menu`;
        const res = await fetch(url, {
            method: isEdit ? 'PUT' : 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload)
        });
        const json = await res.json();

        if (!res.ok || !json.success) {
            const detail = Array.isArray(json.errors) ? `: ${json.errors.join(', ')}` : '';
            throw new Error((json.message || 'Gagal menyimpan menu') + detail);
        }

        showToast(isEdit ? 'Hidangan berhasil diperbarui.' : 'Hidangan baru berhasil ditambahkan.', 'success');
        closeMenuModal();
        await refreshAll();
    } catch (err) {
        console.error('Submit error:', err);
        showToast(err.message || 'Terjadi kesalahan sistem', 'error');
    } finally {
        elements.btnSubmitMenu.disabled = false;
        btnText.textContent = 'Simpan Menu';
    }
}

async function handleDeleteMenu() {
    if (!state.deleteTargetId) return;

    elements.btnConfirmDelete.disabled = true;
    elements.btnConfirmDelete.textContent = 'Menghapus…';

    try {
        const res = await fetch(`${API_BASE}/menu/${state.deleteTargetId}`, { method: 'DELETE' });
        const json = await res.json();
        if (!res.ok || !json.success) throw new Error(json.message || 'Gagal menghapus menu');

        showToast('Hidangan telah dihapus.', 'info');
        closeDeleteModal();
        closeDetailModal();
        await refreshAll();
    } catch (err) {
        console.error('Delete error:', err);
        showToast(err.message || 'Gagal menghapus menu', 'error');
    } finally {
        elements.btnConfirmDelete.disabled = false;
        elements.btnConfirmDelete.textContent = 'Ya, Hapus';
    }
}

// ========================================================
// PENCARIAN, FILTER, TAMPILAN
// ========================================================
let searchDebounceTimer = null;
elements.searchInput.addEventListener('input', (e) => {
    const val = e.target.value;
    elements.btnClearSearch.style.display = val ? 'block' : 'none';
    clearTimeout(searchDebounceTimer);
    searchDebounceTimer = setTimeout(() => {
        state.search = val;
        state.page = 1;
        loadMenu();
    }, 300);
});

elements.btnClearSearch.addEventListener('click', () => {
    elements.searchInput.value = '';
    elements.btnClearSearch.style.display = 'none';
    state.search = '';
    state.page = 1;
    loadMenu();
    elements.searchInput.focus();
});

elements.categoriesContainer.addEventListener('click', (e) => {
    const btn = e.target.closest('.cat-tab');
    if (!btn) return;
    const cat = btn.getAttribute('data-category');
    if (state.category === cat) return;
    state.category = cat;
    state.page = 1;
    renderCategories();
    loadMenu();
});

elements.sortSelect.addEventListener('change', (e) => {
    const [sortBy, order] = e.target.value.split('-');
    state.sortBy = sortBy;
    state.order = order.toUpperCase();
    state.page = 1;
    loadMenu();
});

elements.statusFilter.addEventListener('change', (e) => {
    state.status = e.target.value;
    state.page = 1;
    loadMenu();
});

elements.limitSelect.addEventListener('change', (e) => {
    state.limit = parseInt(e.target.value, 10);
    state.page = 1;
    loadMenu();
});

function setView(view) {
    state.view = view === 'list' ? 'list' : 'grid';
    storageSet('rn_view', state.view);
    elements.viewButtons.forEach(b => {
        const active = b.getAttribute('data-view') === state.view;
        b.classList.toggle('active', active);
        b.setAttribute('aria-pressed', active);
    });
}

elements.viewButtons.forEach(btn => {
    btn.addEventListener('click', () => {
        if (btn.getAttribute('data-view') === state.view) return;
        setView(btn.getAttribute('data-view'));
        if (state.items.length) renderMenuGrid();
    });
});

function resetAllFilters() {
    state.search = '';
    state.category = 'Semua';
    state.status = 'semua';
    state.sortBy = 'id';
    state.order = 'DESC';
    state.page = 1;

    elements.searchInput.value = '';
    elements.btnClearSearch.style.display = 'none';
    elements.sortSelect.value = 'id-desc';
    elements.statusFilter.value = 'semua';

    renderCategories();
    loadMenu();
}

elements.btnResetFilters.addEventListener('click', resetAllFilters);
elements.btnEmptyReset.addEventListener('click', resetAllFilters);

// Pratinjau URL foto
elements.inputGambar.addEventListener('input', (e) => {
    const url = e.target.value.trim();
    if (url) {
        elements.imagePreview.onerror = () => elements.imagePreview.classList.add('hidden');
        elements.imagePreview.onload = () => elements.imagePreview.classList.remove('hidden');
        elements.imagePreview.src = url;
    } else {
        elements.imagePreview.src = '';
        elements.imagePreview.classList.add('hidden');
    }
});

// ========================================================
// MODE ADMIN
// ========================================================
function setAdmin(on, { silent = false } = {}) {
    state.admin = Boolean(on);
    document.body.classList.toggle('is-admin', state.admin);
    elements.btnAdminToggle.setAttribute('aria-pressed', state.admin);
    storageSet('rn_admin', state.admin ? '1' : '0');

    if (!state.admin) {
        closeMenuModal();
        closeDeleteModal();
    } else {
        checkServerHealth();
    }

    if (!silent) {
        showToast(state.admin ? 'Mode Admin aktif.' : 'Mode Admin dimatikan.', 'info');
    }
}

elements.btnAdminToggle.addEventListener('click', () => setAdmin(!state.admin));

// ========================================================
// EVENT MODAL
// ========================================================
elements.btnOpenAddModal.addEventListener('click', openAddModal);
elements.btnCloseModal.addEventListener('click', closeMenuModal);
elements.btnCancelModal.addEventListener('click', closeMenuModal);
elements.menuForm.addEventListener('submit', handleMenuSubmit);

elements.btnCloseDetail.addEventListener('click', closeDetailModal);
elements.btnEditFromDetail.addEventListener('click', () => {
    const item = state.currentDetailItem;
    closeDetailModal();
    openEditModal(item);
});
elements.btnDeleteFromDetail.addEventListener('click', () => openDeleteModal(state.currentDetailItem));

elements.btnCancelDelete.addEventListener('click', closeDeleteModal);
elements.btnConfirmDelete.addEventListener('click', handleDeleteMenu);

// Klik di luar dialog untuk menutup
allModals.forEach(modal => {
    modal.addEventListener('click', (e) => {
        if (e.target === modal) {
            if (modal === elements.detailModal) closeDetailModal();
            else if (modal === elements.deleteModal) closeDeleteModal();
            else closeMenuModal();
        }
    });
});

window.addEventListener('keydown', (e) => {
    if (e.key !== 'Escape') return;
    // Tutup lapisan teratas lebih dulu
    if (!elements.deleteModal.classList.contains('hidden')) return closeDeleteModal();
    if (!elements.menuModal.classList.contains('hidden')) return closeMenuModal();
    if (!elements.detailModal.classList.contains('hidden')) return closeDetailModal();
    setNavOpen(false);
});

// ========================================================
// HEADER, NAVIGASI & ANIMASI
// ========================================================
function onScroll() {
    elements.siteHeader.classList.toggle('scrolled', window.scrollY > 40);
}
window.addEventListener('scroll', onScroll, { passive: true });

function setNavOpen(open) {
    elements.siteHeader.classList.toggle('nav-open', open);
    elements.btnBurger.setAttribute('aria-expanded', open);
}

elements.btnBurger.addEventListener('click', () => {
    setNavOpen(!elements.siteHeader.classList.contains('nav-open'));
});
elements.mobileNav.addEventListener('click', (e) => {
    if (e.target.closest('a')) setNavOpen(false);
});

function initReveal() {
    const items = document.querySelectorAll('.reveal');
    if (!('IntersectionObserver' in window)) {
        items.forEach(el => el.classList.add('is-visible'));
        return;
    }
    const io = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('is-visible');
                io.unobserve(entry.target);
            }
        });
    }, { threshold: 0.12, rootMargin: '0px 0px -40px 0px' });

    items.forEach((el, i) => {
        el.style.transitionDelay = `${(i % 4) * 90}ms`;
        io.observe(el);
    });
}

// ========================================================
// INISIALISASI
// ========================================================
async function init() {
    setView(state.view);
    setAdmin(state.admin, { silent: true });
    populateCategorySelect();
    onScroll();
    initReveal();

    await checkServerHealth();
    await Promise.all([loadStats(), loadCategories(), loadSignature()]);
    await loadMenu();

    setInterval(() => { if (state.admin) checkServerHealth(); }, 30000);
}

document.addEventListener('DOMContentLoaded', init);
